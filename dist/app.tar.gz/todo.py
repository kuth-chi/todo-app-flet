""" Import flet from flet library """
import flet as ft


class Task(ft.Column):
    """ Task class to represent each to-do item """

    def __init__(self, task_name, task_status_change, task_delete):
        super().__init__()
        self.completed = False
        self.task_name = task_name
        self.task_status_change = task_status_change
        self.task_delete = task_delete
        self.display_task = ft.Checkbox(
            value=False, label=self.task_name, on_change=self.status_changed
        )
        self.edit_name = ft.TextField(expand=1)

        self.display_view = ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                self.display_task,
                ft.Row(
                    spacing=0,
                    controls=[
                        ft.IconButton(
                            icon=ft.icons.CREATE_OUTLINED,
                            tooltip="Edit",
                            on_click=self.edit_clicked,
                        ),
                        self.delete_button(),
                    ],
                ),
            ],
        )

        self.edit_view = ft.Row(
            visible=False,
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                self.edit_name,
                ft.IconButton(
                    icon=ft.icons.DONE_OUTLINE_OUTLINED,
                    icon_color=ft.colors.GREEN,
                    tooltip="Update",
                    on_click=self.save_clicked,
                ),
            ],
        )
        self.controls = [self.display_view, self.edit_view]

    def delete_button(self):
        """ Add style on delete button when hover event """
        delete_button = ft.IconButton(
            icon=ft.icons.DELETE_OUTLINED,
            tooltip="Delete",
            on_click=self.delete_clicked,
        )
        def on_hover(e):
            delete_button.icon_color = ft.colors.WHITE if e.data == True else None
            delete_button.hover_color = ft.colors.RED_400
            delete_button.update()
        delete_button.on_hover = on_hover
        return delete_button
    
    
    def edit_clicked(self, e):
        """ Edit To-Do button click event """
        self.edit_name.value = self.display_task.label
        self.display_view.visible = False
        self.edit_view.visible = True
        self.update()

    def save_clicked(self, e):
        """ Save To-Do button click event """
        self.display_task.label = self.edit_name.value
        self.display_view.visible = True
        self.edit_view.visible = False
        self.update()

    def status_changed(self, e):
        """ Status checkbox change event """
        self.completed = self.display_task.value
        self.task_status_change()

    def delete_clicked(self, e):
        """ Delete To-Do button click event """
        self.task_delete(self)


class TodoApp(ft.Column):
    """ application's root control is a Column containing all other controls """

    def __init__(self):
        super().__init__()
        self.new_task = ft.TextField(
            hint_text="Whats needs to be done?", expand=True)
        self.tasks = ft.Column()

        self.filter = ft.Tabs(
            selected_index=0,
            on_change=self.tabs_changed,
            tabs=[ft.Tab(text="all"), ft.Tab(text="active"),
                  ft.Tab(text="completed")],
        )

        self.items_left = ft.Text("0 items left")
        self.width = 600
        self.controls = [
            ft.Row(
                [ft.Text(value="To-Do App",
                         theme_style=ft.TextThemeStyle.TITLE_MEDIUM)],
                alignment=ft.MainAxisAlignment.CENTER,
            ),

            ft.Row(
                controls=[
                    self.new_task,
                    ft.FloatingActionButton(
                        icon=ft.icons.ADD, on_click=self.add_clicked,
                        tooltip="Add ToDo",
                    ),
                ],
            ),
            ft.Column(
                spacing=25,
                controls=[
                    self.filter,
                    self.tasks,
                    ft.Row(
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        controls=[
                            self.items_left,
                            ft.OutlinedButton(
                                text="Clear completed", on_click=self.clear_clicked,
                                tooltip="Clear selected ToDos"
                            ),
                        ],
                    ),
                ],
            ),
        ]

    def add_clicked(self, e):
        """ Add To-Do button click event """
        task = Task(self.new_task.value,
                    self.task_status_change, self.task_delete)
        self.tasks.controls.append(task)
        self.new_task.value = ""
        self.update()

    def task_status_change(self):
        """ Task status change event """
        self.update()

    def task_delete(self, task):
        """ Task delete event """
        self.tasks.controls.remove(task)
        self.update()

    def clear_clicked(self, e):
        """ Clear completed To-Do button click event """
        for task in self.tasks.controls[:]:
            if task.completed:
                self.task_delete(task)

    def before_update(self):
        """ Before update event """
        status = self.filter.tabs[self.filter.selected_index].text
        count = 0
        for task in self.tasks.controls:
            task.visible = (
                status == "all"
                or (status == "active" and task.completed is False)
                or (status == "completed" and task.completed)
            )
            if not task.completed:
                count += 1
                
                    
        self.items_left.value = f"{count} active item(s) left"

    def tabs_changed(self, e):
        """ Tabs change event """
        self.update()


# async def main(page: ft.Page):
#     """ Main page handle of application """
#     page.title = "Todo App"
#     page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
#     page.update()

#     # create application instance
#     app = TodoApp()

#     # add application's root control to the page
#     page.add(app)


# ft.app(target=main)
